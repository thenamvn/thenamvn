OOP Project
![image](https://github.com/thenamdev/vju2023_project_oop/assets/57611937/a961768a-dc45-4d49-85d5-c269977270c3)

![image](https://github.com/thenamdev/vju2023_project_oop/assets/57611937/618cfd92-c0d0-49e3-9a44-32c13f637c4d)
![image](https://github.com/thenamdev/vju2023_project_oop/assets/57611937/264805ac-ecc2-4921-a727-c64fccdab403)

